<?php
// Inclui a conexão
include 'php/conexao.php';

// Query principal: Lista cidades com o nome do país (JOIN)
$sql = "SELECT c.*, p.nome as pais_nome 
        FROM cidades c 
        JOIN paises p ON c.id_pais = p.id_pais 
        ORDER BY p.nome, c.nome";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Cidades - CRUD Mundo</title>
    
    <style>
        body {
            background-color: #1a1a1a;
            color: #f0f0f0;
            margin: 0;
            padding: 20px;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: normal;
            font-size: 1.8rem;
        }

        .back-button {
            display: inline-block;
            margin-bottom: 20px;
            color: #888;
            text-decoration: none;
            padding: 5px 0;
        }

        .back-button:hover {
            color: #f0f0f0;
        }

        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: #f0f0f0;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background-color: #2a5a7a;
        }

        .btn-edit:hover {
            background-color: #3a6a8a;
        }

        .btn-delete {
            background-color: #7a2a2a;
        }

        .btn-delete:hover {
            background-color: #8a3a3a;
        }

        .table-container {
            background-color: #2a2a2a;
            border: 1px solid #333;
            border-radius: 4px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #333;
        }

        th {
            background-color: #333;
            color: #f0f0f0;
            font-weight: normal;
        }

        tr:hover {
            background-color: #333;
        }

        .actions {
            display: flex;
            gap: 10px;
        }

        .weather {
            font-size: 0.9rem;
            color: #4a9a4a;
        }

        .loading {
            color: #888;
            font-style: italic;
        }

        .no-weather {
            color: #f55;
            font-style: italic;
            font-weight: bold;
        }

        .success-message {
            background: linear-gradient(135deg, #2a5a7a, #3a6a8a);
            color: #fff;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            border: 1px solid #4a7a9a;
            font-size: 1rem;
        }

        .error-message {
            background: linear-gradient(135deg, #7a2a2a, #8a3a3a);
            color: #fff;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            border: 1px solid #9a4a4a;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="back-button">← Voltar para Início</a>
        <h1>Lista de Cidades</h1>

        <?php
        if (isset($_GET['sucesso'])) {
            echo '<div class="success-message" id="successMessage">' . htmlspecialchars($_GET['sucesso']) . '</div>';
        }
        if (isset($_GET['erro'])) {
            echo '<div class="error-message" id="errorMessage">' . htmlspecialchars($_GET['erro']) . '</div>';
        }
        ?>

        <?php if ($result->num_rows > 0) { ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cidade</th>
                        <th>País</th>
                        <th>População</th>
                        <th>Clima</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id_cidade']; ?></td>
                        <td><?php echo htmlspecialchars($row['nome']); ?></td>
                        <td><?php echo htmlspecialchars($row['pais_nome']); ?></td>
                        <td><?php echo $row['populacao'] ? number_format($row['populacao']) : 'N/A'; ?></td>
                        <td class="weather" id="weather-<?php echo $row['id_cidade']; ?>">
                            <span class="loading">🌤️ Buscando clima...</span>
                        </td>
                        <td class="actions">
                            <a href="editar_cidade.php?id=<?php echo $row['id_cidade']; ?>" class="btn btn-edit">Editar</a>
                            <a href="php/excluir_cidade.php?id=<?php echo $row['id_cidade']; ?>" class="btn btn-delete" onclick="return confirm('Tem certeza que deseja excluir esta cidade?')">Excluir</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <?php } else { ?>
            <div style="text-align:center; padding:40px; color:#888;">Nenhuma cidade cadastrada.</div>
        <?php } ?>

        <?php $conn->close(); ?>
    </div>

<script>
    const apiKey = '70d01e04fafa2592962185d185c05d34';

    async function getWeather(cityName) {
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(cityName)}&units=metric&lang=pt_br&appid=${apiKey}`;

        try {
            const response = await fetch(url);

            if (response.status === 404) {
                return "cidade não encontrada";
            }

            if (!response.ok) {
                return "cidade não encontrada";
            }

            const data = await response.json();

            if (!data.main || !data.weather) {
                return "cidade não encontrada";
            }

            const temp = data.main.temp.toFixed(1);
            const desc = data.weather[0].description;
            const icon = `https://openweathermap.org/img/wn/${data.weather[0].icon}.png`;

            return `${temp}°C <img src="${icon}" style="width:20px;vertical-align:middle;"> ${desc}`;

        } catch (error) {
            return "cidade não encontrada";
        }
    }

    async function carregarClimas() {
        const weatherCells = document.querySelectorAll('[id^="weather-"]');

        for (const cell of weatherCells) {
            const row = cell.closest('tr');
            const cityName = row.querySelector('td:nth-child(2)').textContent.trim();
            const countryName = row.querySelector('td:nth-child(3)').textContent.trim();
            const searchQuery = `${cityName},${countryName}`;

            cell.innerHTML = '<span class="loading">🌤️ Buscando clima...</span>';

            const weather = await getWeather(searchQuery);

            if (weather === "cidade não encontrada") {
                cell.innerHTML = `<span class="no-weather">cidade não encontrada</span>`;
            } else {
                cell.innerHTML = weather;
            }
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        carregarClimas();

        const successMessage = document.getElementById('successMessage');
        const errorMessage = document.getElementById('errorMessage');

        function hideMessage(element) {
            if (element) setTimeout(() => element.remove(), 3000);
        }

        hideMessage(successMessage);
        hideMessage(errorMessage);
    });
</script>

</body>
</html>
